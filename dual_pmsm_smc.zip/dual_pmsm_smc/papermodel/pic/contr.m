t = -8:0.1:8;
y1 = 0.7*atan(t);
y = sign(t);
y2 = t/(abs(t)+0.5);
plot(t,y2)
